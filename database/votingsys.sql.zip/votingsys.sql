-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2022 at 10:37 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `votingsys`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `aname` varchar(50) NOT NULL,
  `aemail` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `aname`, `aemail`, `password`) VALUES
(1, 'admin1', 'admin1@gmail.com', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `cid` int(11) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `cAge` int(10) NOT NULL,
  `cGender` varchar(10) NOT NULL,
  `eType` varchar(50) NOT NULL,
  `cPic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`cid`, `cname`, `cAge`, `cGender`, `eType`, `cPic`) VALUES
(4, 'imad', 21, 'male', 'Gram Panchayat Election', '../images/one.jpg'),
(6, 'chirag', 24, 'male', 'State Election', '../images/665373.jpg'),
(7, 'ramya', 22, 'female', 'Taluk Panchayat Election', '../images/images1.jpg'),
(8, 'vismaya', 20, 'female', 'State Election', '../images/two1.jpg'),
(9, 'abhi', 22, 'male', 'Central Election', '../images/180289.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cityzens`
--

CREATE TABLE `cityzens` (
  `aadhar` bigint(15) NOT NULL,
  `phone` bigint(12) NOT NULL,
  `name` varchar(15) NOT NULL,
  `bdate` varchar(8) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `age` int(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cityzens`
--

INSERT INTO `cityzens` (`aadhar`, `phone`, `name`, `bdate`, `gender`, `age`, `address`) VALUES
(243160793326, 8971683419, 'Pruthvi T', '19021998', 'Male', 21, 'sdmit,ujire'),
(252585859696, 9591478857, 'ramya', '30052001', 'female', 22, 'hwdgy'),
(285698013874, 963258741, 'chirag', '5122000', 'male', 20, 'madikeri'),
(963258741024, 4181045814, 'aksh', '16082005', 'male', 22, 'tumkuru');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `v_id` int(50) NOT NULL,
  `v_name` varchar(50) NOT NULL,
  `v_adhhar` bigint(13) NOT NULL,
  `eType` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`v_id`, `v_name`, `v_adhhar`, `eType`) VALUES
(1, 'aksh', 963258741024, 'Central Election'),
(2, 'aksh', 963258741024, 'Taluk Panchayat Election');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `cid` int(50) NOT NULL,
  `cname` varchar(50) NOT NULL,
  `etype` varchar(50) NOT NULL,
  `votes` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`cid`, `cname`, `etype`, `votes`) VALUES
(4, 'imad', 'Gram Panchayat Election', 4),
(6, 'chirag', 'State Election', 4),
(7, 'ramya', 'Taluk Panchayat Election', 2),
(8, 'vismaya', 'State Election', 6),
(9, 'abhi', 'Central Election', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `cityzens`
--
ALTER TABLE `cityzens`
  ADD PRIMARY KEY (`aadhar`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`v_id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`cid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `v_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `candidates` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
